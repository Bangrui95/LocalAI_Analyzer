//------------------------------------------------------
// Element bindings
//------------------------------------------------------
const exportBtn = document.getElementById("exportBtn");
const analyzeBtn = document.getElementById("analyzeBtn");
const viewBtn = document.getElementById("viewBtn");
const settingsBtn = document.getElementById("settingsBtn");
const status = document.getElementById("status");
const runCircleBtn = document.getElementById("runCircleBtn");


//------------------------------------------------------
// Backend status LED control for START button
//------------------------------------------------------
function setStartStatusOK() {
  runCircleBtn.classList.remove("status-error", "status-running");
  runCircleBtn.classList.add("status-ok");
}

function setStartStatusError() {
  runCircleBtn.classList.remove("status-ok", "status-running");
  runCircleBtn.classList.add("status-error");
}

function setStartStatusRunning() {
  runCircleBtn.classList.remove("status-ok", "status-error");
  runCircleBtn.classList.add("status-running");
}


//------------------------------------------------------
// Check Python backend status
//------------------------------------------------------
async function checkBackendStatus() {
  try {
    const res = await fetch("http://127.0.0.1:11668/ping");

    if (res.ok) {
      status.textContent = "Backend connected";
      status.style.color = "#00c3ff";
      analyzeBtn.disabled = false;

      setStartStatusOK();
    } else {
      throw new Error("Backend did not respond");
    }

  } catch (err) {
    status.textContent = "Backend not running. Please start LocalAI_analyse.";
    status.style.color = "#ff7070";
    analyzeBtn.disabled = true;

    setStartStatusError();
  }
}

// Run backend check when popup opens
document.addEventListener("DOMContentLoaded", checkBackendStatus);


//------------------------------------------------------
// Export browsing history
//------------------------------------------------------
exportBtn.addEventListener("click", () => {
  status.textContent = "Exporting browsing history...";
  status.style.color = "#00bfff";

  chrome.runtime.sendMessage({ type: "EXPORT_HISTORY" }, (resp) => {
    if (chrome.runtime.lastError) {
      status.textContent =
        "Communication error: " + chrome.runtime.lastError.message;
      status.style.color = "#ff7070";
      return;
    }

    if (resp && resp.ok) {
      status.textContent = "Export completed (saved to Downloads folder)";
      status.style.color = "#00e0ff";
    } else {
      status.textContent =
        "Export failed: " + (resp?.err || "Unknown error");
      status.style.color = "#ff7070";
    }
  });
});


//------------------------------------------------------
// Run local Python analysis
//------------------------------------------------------
analyzeBtn.addEventListener("click", () => {
  status.textContent = "Running local analysis...";
  status.style.color = "#00bfff";

  // Show breathing animation while processing
  setStartStatusRunning();

  chrome.runtime.sendMessage({ type: "RUN_PYTHON_ANALYSIS" }, (resp) => {
    if (chrome.runtime.lastError) {
      status.textContent =
        "Communication error: " + chrome.runtime.lastError.message;
      status.style.color = "#ff7070";

      setStartStatusError();
      return;
    }

    if (resp && resp.ok) {
      status.textContent =
        "Analysis complete. Opening results page...";
      status.style.color = "#00e0ff";

      setStartStatusOK();

      chrome.tabs.create({ url: "index.html" });

    } else {
      status.textContent =
        "Analysis failed: " + (resp?.err || "Unknown error");
      status.style.color = "#ff7070";

      setStartStatusError();
    }
  });
});


//------------------------------------------------------
// Open results page
//------------------------------------------------------
viewBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: "index.html" });
});


//------------------------------------------------------
// Open settings page
//------------------------------------------------------
settingsBtn.addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});


//------------------------------------------------------
// START button: Export + Analyze (combined execution)
//------------------------------------------------------
runCircleBtn.addEventListener("click", async () => {
  const exportBtn = document.getElementById("exportBtn");
  const analyzeBtn = document.getElementById("analyzeBtn");

  if (!exportBtn || !analyzeBtn) {
    console.warn("Required buttons not found. Combined run aborted.");
    return;
  }

  // Step 1 — Export history
  exportBtn.click();
  console.log("Export process initiated.");

  // Step 2 — After a delay, start analysis
  setTimeout(() => {
    analyzeBtn.click();
    console.log("Local analysis initiated.");
  }, 1500);
});