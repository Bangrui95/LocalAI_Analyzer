//------------------------------------------------------
// 📦 插件首次安装
//------------------------------------------------------
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set(
    {
      installedAt: new Date().toISOString(),

      // Browsing / Analysis Defaults
      historyDays: 30,          // 默认历史天数
      granularityLevel: 2,      // 默认标签层级
      samplingCount: 50,        // 默认采样数量
      siteBlacklist: [],        // 默认空黑名单
      // Parsing
      useDeepParsing: true,     // 默认启用深度解析
      // Personalized Page
      newtabEnabled: false,     // 默认关闭个性化推荐页
      // RSS Settings
      rssSources: [],           // 默认空 RSS 列表
      rssDays: 14,              // 默认时间窗口 14 天
      rssCount: 20,             // 默认推荐数量
      rssAutoUpdateHours: 1,    // 默认每 1 小时自动更新
      rssAutoUpdateEnabled: true
    },
    () => console.log("Initial settings have been configured.")
  );
});


//------------------------------------------------------
// 🧭 抓取浏览历史
//------------------------------------------------------
async function fetchHistory(days = 30) {
  const dayMs = 24 * 60 * 60 * 1000;
  const now = Date.now();

  let total = [];
  let rangeDays = 0;
  const step = 15;     // 每次查询 15 天
  const maxLimit = 5000; // Chrome 限制
  let done = false;

  console.log(`⏳ 正在抓取浏览历史：目标 ${days} 天内，最多 ${maxLimit} 条。`);

  while (!done) {
    const startTime = now - (rangeDays + step) * dayMs;
    const endTime = now - rangeDays * dayMs;

    const results = await new Promise((resolve) => {
      chrome.history.search(
        { text: "", startTime, endTime, maxResults: 1000 },
        (res) => resolve(res || [])
      );
    });

    total.push(...results);
    console.log(`📅 已累计 ${total.length} 条，范围约 ${rangeDays + step} 天内`);

    rangeDays += step;
    if (results.length === 0 || total.length >= maxLimit || rangeDays >= days) {
      done = true;
      console.log(`✅ 完成抓取：共 ${total.length} 条（约 ${rangeDays} 天内）`);
    }

    // 小睡一下，避免压力太大
    await new Promise((r) => setTimeout(r, 200));
  }

  // 去重 + 按时间排序
  const unique = Array.from(
    new Map(total.map((r) => [r.id || r.url, r])).values()
  ).sort((a, b) => b.lastVisitTime - a.lastVisitTime);

  const processed = unique.map((r) => ({
    hostname: (() => {
      try {
        return new URL(r.url).hostname;
      } catch {
        return "(local)";
      }
    })(),
    title: r.title || "(NONE)",
    url: r.url,
    lastVisitTime: new Date(r.lastVisitTime).toISOString(),
    visitCount: r.visitCount || 1,
    description: "(NONE)",
    embeddingText: "(NONE)"
  }));

  chrome.storage.local.set({ historyData: processed }, () => {
    console.log(`✅ 已缓存 ${processed.length} 条历史记录`);
  });

  return processed;
}


//------------------------------------------------------
// 💾 确保下载目录存在
//------------------------------------------------------
async function ensureDownloadFolderExists(folderName) {
  try {
    const initId = await chrome.downloads.download({
      url: "data:text/plain,init",
      filename: `${folderName}/.init.txt`,
      saveAs: false
    });
    await chrome.downloads.erase({ id: initId });
  } catch (err) {
    console.warn("⚠️ 无法预创建下载目录:", err.message);
  }
}


//------------------------------------------------------
// 🔗 通知 Python 后端（文件名 + 参数）
//------------------------------------------------------
async function notifyPythonBackend(filename) {
  try {
    const {
      historyDays,
      granularityLevel,
      samplingCount,
      siteBlacklist = [],
      useDeepParsing = true
    } = await new Promise((resolve) =>
      chrome.storage.local.get(
        ["historyDays", "granularityLevel", "samplingCount", "siteBlacklist", "useDeepParsing"],
        resolve
      )
    );

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2000);

    const res = await fetch("http://127.0.0.1:11668/notify_download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        filename,
        settings: {
          historyDays,
          granularityLevel,
          samplingCount,
          siteBlacklist,
          useDeepParsing // ✅ 传给后端，后端知道该不该用 BeautifulSoup
        }
      }),
      signal: controller.signal
    });

    clearTimeout(timeout);
    const data = await res.json();
    console.log("📨 后端已接收:", data);
  } catch (err) {
    console.warn("⚠️ 后端通知失败:", err.message);
  }
}


//------------------------------------------------------
// 📤 导出 JSON 文件并通知后端
//------------------------------------------------------
async function exportHistoryToJSON() {
  try {
    // 从 storage 中读取配置
    const {
      historyDays = 30,
      siteBlacklist = [],
      useDeepParsing = true
    } = await new Promise((resolve) =>
      chrome.storage.local.get(
        ["historyDays", "siteBlacklist", "useDeepParsing"],
        resolve
      )
    );

    console.log(`📅 当前导出天数设置: ${historyDays} 天`);
    const historyData = await fetchHistory(historyDays);

    // 黑名单过滤
    const filtered = historyData.filter(
      (item) => !siteBlacklist.some((domain) => item.url.includes(domain))
    );
    console.log(`🧹 过滤黑名单后剩余 ${filtered.length} 条。`);

    const {
      installedAt,
      granularityLevel,
      samplingCount
    } = await new Promise((resolve) =>
      chrome.storage.local.get(
        ["installedAt", "granularityLevel", "samplingCount"],
        resolve
      )
    );

    // ✅ 在 settings 中加入 useDeepParsing
    const jsonData = {
      generatedAt: new Date().toISOString(),
      installedAt: installedAt || "(unknown)",
      totalCount: filtered.length,
      settings: {
        historyDays,
        granularityLevel,
        samplingCount,
        siteBlacklist,
        useDeepParsing // ✅ 告诉后端 “下次分析要不要爬网页”
      },
      items: filtered
    };

    // 导出 JSON 文件
    const folderName = "browser_history";
    await ensureDownloadFolderExists(folderName);
    const filename = `${folderName}/history_${Date.now()}.json`;

    const base64 = btoa(
      unescape(encodeURIComponent(JSON.stringify(jsonData, null, 2)))
    );
    const dataUrl = "data:application/json;base64," + base64;

    await chrome.downloads.download({
      url: dataUrl,
      filename,
      saveAs: false,
      conflictAction: "overwrite"
    });

    console.log(`✅ 导出完成: ${filename}`);

    // 通知 Python 后端我们刚刚导出了哪个文件
    await notifyPythonBackend(filename);
  } catch (err) {
    console.error("❌ 导出失败:", err);
  }
}


//------------------------------------------------------
// 💬 监听来自 popup、index 或 options 的消息
//------------------------------------------------------
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {

  // 📤 导出浏览历史
  if (msg.type === "EXPORT_HISTORY") {
    exportHistoryToJSON()
      .then(() => sendResponse({ ok: true }))
      .catch((err) =>
        sendResponse({ ok: false, err: err.message })
      );
    return true; // 异步响应
  }

  // 🧠 请求后端运行分析
  if (msg.type === "RUN_PYTHON_ANALYSIS") {
    chrome.storage.local.get(
      [
        "historyDays",
        "granularityLevel",
        "samplingCount",
        "siteBlacklist",
        "useDeepParsing"
      ],
      async ({
        historyDays,
        granularityLevel,
        samplingCount,
        siteBlacklist = [],
        useDeepParsing = true
      }) => {
        try {
          const res = await fetch("http://127.0.0.1:11668/analyze", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              settings: {
                historyDays,
                granularityLevel,
                samplingCount,
                siteBlacklist,
                useDeepParsing
              }
            })
          });

          const data = await res.json();
          chrome.storage.local.set({ pythonAnalysis: data }, () => {
            console.log("✅ 已接收分析结果:", data);
            sendResponse({ ok: true });
          });
        } catch (err) {
          console.error("❌ 分析请求失败:", err);
          sendResponse({ ok: false, err: err.message });
        }
      }
    );
    return true;
  }

  // ⚙️ 更新设置（options 页面）
  if (msg.type === "REFRESH_SETTINGS") {
    const {
      historyDays,
      granularityLevel,
      samplingCount,
      siteBlacklist = [],
      useDeepParsing
    } = msg.value || {};

    chrome.storage.local.set(
      {
        historyDays,
        granularityLevel,
        samplingCount,
        siteBlacklist,
        useDeepParsing
      },
      () => {
        console.log(
          `⚙️ 新设置: days=${historyDays}, level=${granularityLevel}, count=${samplingCount}, blacklist=${siteBlacklist.length}, deepParsing=${useDeepParsing}`
        );
        sendResponse({ ok: true });
      }
    );
    return true;
  }

  // 🟢 新增：保存自定义分析文件
  if (msg.type === "SAVE_CUSTOM_ANALYSIS") {
    console.log("💾 收到保存请求，正在发送到后端...");
    fetch("http://127.0.0.1:11668/save_custom_analysis", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(msg.payload),
    })
      .then((res) => res.json())
      .then((data) => {
        console.log("✅ 保存成功:", data);
        sendResponse({ ok: true, data });
      })
      .catch((err) => {
        console.error("❌ 保存失败:", err);
        sendResponse({ ok: false, err: err.message });
      });
    return true; // 异步响应
  }

});


//------------------------------------------------------
// 🚀 启动时预加载（轻量化）
//------------------------------------------------------
chrome.storage.local.get({ historyDays: 30 }, ({ historyDays }) => {
  console.log(`🧭 插件启动：预加载 ${historyDays} 天历史...`);
  fetchHistory(historyDays);
});
