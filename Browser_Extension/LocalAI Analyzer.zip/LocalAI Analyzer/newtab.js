// ======================================================
// 🔹 newtab.js — 动态加载推荐结果（带本地缓存回退）
// ======================================================

//------------------------------------------------------
// Personalized Newtab Switch Logic (Unified Dark UI)
//------------------------------------------------------
document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get({ newtabEnabled: false }, (data) => {
    if (!data.newtabEnabled) {
      console.log("Personalized newtab disabled → showing info message");

      // Reset document and apply full-screen layout
      document.body.innerHTML = "";
      document.body.className = "";
      document.documentElement.style.cssText = `
        margin:0;
        padding:0;
        width:100vw;
        height:100vh;
        background:#000000;
        overflow:hidden;
      `;
      document.body.style.cssText = `
        margin:0;
        padding:0;
        width:100vw;
        height:100vh;
        display:flex;
        flex-direction:column;
        align-items:center;
        justify-content:flex-start;
        font-family:Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        background:none;
        color:#cbd5e1;
      `;

      // Soft ambient glow
      const glow = document.createElement("div");
      glow.style.cssText = `
        position:fixed;
        width:340px;
        height:340px;
        background:radial-gradient(circle, rgba(0,140,255,0.25), transparent 70%);
        top:35%;
        left:50%;
        transform:translate(-50%,-50%);
        filter:blur(80px);
        z-index:0;
        animation:pulse 6s ease-in-out infinite;
      `;

      // ======================================================
// Search Box — unified dark/blue style
// ======================================================
const searchBox = document.createElement("div");
searchBox.innerHTML = `
  <input 
    type="text"
    placeholder="Search Google or type a URL"
    id="customSearchBox"
    style="
      width:560px;
      max-width:85vw;
      padding:12px 18px;
      font-size:16px;
      color:#e6edf3;
      background:#070708;
      border:2.66px solid rgba(110,160,255,0.10);
      border-radius:40px;
      outline:none;
      margin-top:12vh;
      margin-bottom:6vh;
      box-shadow:
        0 0 22px rgba(0,25,50,0.45),
        0 0 0 1px rgba(110,160,255,0.05);
      transition:border-color 0.25s ease, box-shadow 0.25s ease;
    "
  />
`;

const inputEl = searchBox.querySelector("input");

// -------------------------------
// Hover effect (same as options page)
// -------------------------------
inputEl.addEventListener("mouseenter", () => {
  inputEl.style.border = "2.66px solid #2a3243";
  inputEl.style.boxShadow =
    "0 0 22px rgba(0,25,50,0.55), 0 0 0 1px rgba(110,160,255,0.05)";
});

inputEl.addEventListener("mouseleave", () => {
  inputEl.style.border = "2.66px solid rgba(110,160,255,0.10)";
  inputEl.style.boxShadow =
    "0 0 22px rgba(0,25,50,0.45), 0 0 0 1px rgba(110,160,255,0.05)";
});

// -------------------------------
// Focus style
// -------------------------------
inputEl.addEventListener("focus", () => {
  inputEl.style.border = "2px solid #3b82f6";
  inputEl.style.boxShadow =
    "0 0 18px rgba(59,130,246,0.35), 0 0 0 1px rgba(59,130,246,0.4)";
});

// -------------------------------
// Blur style
// -------------------------------
inputEl.addEventListener("blur", () => {
  inputEl.style.border = "1px solid rgba(110,160,255,0.10)";
  inputEl.style.boxShadow =
    "0 0 22px rgba(0,25,50,0.45), 0 0 0 1px rgba(110,160,255,0.05)";
});

// -------------------------------
// Enter = Search or Go to URL
// -------------------------------
inputEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    const q = e.target.value.trim();
    if (!q) return;
    if (/^https?:\/\//i.test(q)) {
      window.location.href = q;
    } else {
      window.location.href =
        `https://www.google.com/search?q=${encodeURIComponent(q)}`;
    }
  }
});

      // ======================================================
      // Info Card — unified with dark-blue card style
      // ======================================================
      const card = document.createElement("div");
      card.style.cssText = `
        position:relative;
        z-index:2;
        max-width:520px;
        padding:2.2vh 3vw;
        border-radius:16px;

        background:#070708;
        border:1px solid rgba(110,160,255,0.10);
        box-shadow:
          0 0 22px rgba(0,25,50,0.55),
          0 0 0 1px rgba(110,160,255,0.05);

        text-align:center;
        color:#cbd5e1;
      `;

      card.innerHTML = `
        <h2 style="
          color:#e6edf3;
          font-size:2.2vh;
          margin-bottom:1.2vh;
          letter-spacing:0.3px;
        ">
          Personalized Page Disabled
        </h2>
        <p style="
          font-size:1.55vh;
          line-height:1.6;
          margin-bottom:2.5vh;
        ">
          Your personalized recommendation dashboard is currently disabled.
          Open the extension settings to enable the personalized newtab page.
        </p>
      `;

      // Settings Button — unified blue gradient button
      const btn = document.createElement("button");
      btn.textContent = "Open Settings";
      btn.style.cssText = `
        padding:1.2vh 2.4vw;
        border:none;
        border-radius:10px;
        font-size:1.55vh;
        font-weight:500;
        color:#fff;
        background:linear-gradient(90deg, #007bff, #00c3ff);
        cursor:pointer;
        box-shadow:0 0 12px rgba(0,195,255,0.4);
        transition:all 0.25s ease;
      `;
      btn.onmouseenter = () =>
        (btn.style.boxShadow = "0 0 16px rgba(0,195,255,0.7)");
      btn.onmouseleave = () =>
        (btn.style.boxShadow = "0 0 12px rgba(0,195,255,0.4)");
      btn.onclick = () => chrome.runtime.openOptionsPage();

      card.appendChild(btn);

      // Pulse animation
      const style = document.createElement("style");
      style.textContent = `
        @keyframes pulse {
          0%,100% { opacity:0.5; transform:translate(-50%, -50%) scale(1); }
          50% { opacity:0.9; transform:translate(-50%, -50%) scale(1.2); }
        }
      `;
      document.head.appendChild(style);

      // Final render
      document.body.appendChild(glow);
      document.body.appendChild(searchBox);
      document.body.appendChild(card);
      return;
    }

    // If enabled → load recommendation page
    console.log("Personalized newtab enabled → loading recommendations");
    loadRecommendations();
  });
});


// ======================================================
// 🔸 主函数：加载推荐内容（新增离线缓存回退）
// ======================================================
async function loadRecommendations() {
  const container = document.getElementById("recommendContainer");
  container.innerHTML = "<p>Connecting to LocalAI backend</p>";

  const backendURL = "http://127.0.0.1:11668/rss_results";

  try {
    // 1️⃣ 检查后端状态
    const pingRes = await fetch("http://127.0.0.1:11668/ping");
    if (!pingRes.ok) throw new Error("Backend not responding. Please ensure LocalAI_analyse is running.");

    container.innerHTML = "<p>Backend connected. Loading personalized results</p>";

    // 2️⃣ 请求推荐数据
    const res = await fetch(backendURL);
    if (!res.ok) throw new Error("Failed to fetch recommendations.");
    const data = await res.json();

    if (!data || !data.recommendations) {
      throw new Error("No valid recommendation data found. Please run RSS_search.py first.");
    }

    // ✅ 成功后缓存数据
    chrome.storage.local.set({ lastRssResults: data }, () => {
      console.log("Cached latest recommendations to local storage");
    });

    // 3️⃣ 渲染
    renderRecommendations(data, container);

  } catch (err) {
    console.error("Failed to load recommendation data:", err);

    // 🚨 如果后端离线 → 尝试读取本地缓存
    chrome.storage.local.get("lastRssResults", (res) => {
      if (res.lastRssResults) {
        console.warn("Using cached recommendation data from local storage");
        renderRecommendations(res.lastRssResults, container, true);
      } else {
        container.innerHTML = `
          <p>Unable to load recommendation data</p>
          <p style="color:#ff7070">${err.message}</p>
          <ul>
            <li>Ensure Python backend is running: <code>python server.py</code></li>
            <li>Ensure <code>rss/rss_recommend.json</code> exists</li>
            <li>Ensure plugin has permission to access localhost</li>
          </ul>
        `;
      }
    });
  }
}


// ======================================================
// 🔸 辅助函数：渲染推荐内容
// ======================================================
function renderRecommendations(data, container, isCached = false) {
  try {
    const recs = data.recommendations;
    let html = `
      <p class="update-time">Updated: ${new Date(data.updated).toLocaleString()} ${isCached ? "(cached)" : ""}</p>
    `;

    for (const r of recs) {
      html += `
        <div class="block">
          <h2>${r.label}</h2>
          <ul>
      `;
      for (const a of r.top_articles) {
        html += `
          <li>
            <a href="${a.link}" target="_blank">${a.title}</a>
            <small>(${a.source} — Score ${a.score.toFixed(3)})</small>
          </li>
        `;
      }
      html += `
          </ul>
        </div>
      `;
    }

    container.innerHTML = html;
  } catch (e) {
    console.error("Render error:", e);
    container.innerHTML = `<p>Failed to render recommendation data.</p>`;
  }
}

// ======================================================
// 🔸 自动触发（保留）
// ======================================================
document.addEventListener("DOMContentLoaded", loadRecommendations);