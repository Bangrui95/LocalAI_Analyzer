// // content.js
// let startTime = Date.now();
// let lastUrl = location.href;

// // 🔹 获取网页描述信息
// function getDescription() {
//   return (
//     document.querySelector('meta[name="description"]')?.content ||                    // 常规 meta
//     document.querySelector('meta[property="og:description"]')?.content ||             // Open Graph
//     document.querySelector('meta[name="twitter:description"]')?.content ||            // Twitter Card
//     document.querySelector('p')?.innerText.slice(0, 200) ||                           // 无 meta 时取首段文字
//     ""
//   );
// }

// // 🔹 上报页面停留时间
// function reportStayTime() {
//   const staySeconds = (Date.now() - startTime) / 1000;
//   if (staySeconds > 0.3) {
//     chrome.runtime.sendMessage({
//       type: "PAGE_DWELL",
//       hostname: location.hostname,       // ✅ 网站域名
//       url: location.href,                // ✅ 完整 URL
//       title: document.title || "",       // ✅ 页面标题
//       description: getDescription(),     // ✅ 新增：网页描述
//       ts: Date.now(),                    // 时间戳
//       time: Number(staySeconds.toFixed(1)) // 页面停留时间（秒）
//     });
//   }
// }

// // 🔹 离开页面或标签页切换时上报
// window.addEventListener("beforeunload", reportStayTime);
// document.addEventListener("visibilitychange", () => {
//   if (document.visibilityState === "hidden") reportStayTime();
// });

// // 🔹 处理 SPA 网站（例如 YouTube、Twitter）
// setInterval(() => {
//   if (location.href !== lastUrl) {
//     reportStayTime();       // 上报前一个页面停留
//     startTime = Date.now(); // 重置计时
//     lastUrl = location.href;
//   }
// }, 2000);